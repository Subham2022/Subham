import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.hibernate.*;
import org.hibernate.cfg.*;
import javax.servlet.annotation.*;
@WebServlet("/StudentEntry")
public class StudentEntry extends HttpServlet
{	
	public void service(HttpServletRequest req,HttpServletResponse res)
			throws ServletException,IOException
	{		
	Transaction tx=null;
	try
		{	res.setContentType("text/html");
			PrintWriter pw=res.getWriter();
			String name=req.getParameter("t1");
			String course=req.getParameter("t2");
			String fees=req.getParameter("t3");
			String phone=req.getParameter("t4");
			String email=req.getParameter("t5");
			
			Configuration cfg=new Configuration();
			SessionFactory sf=cfg.configure().buildSessionFactory();
			Session ss=sf.openSession();
			Student s=new Student();
			s.setName(name);
			s.setCourse(course);
			s.setFees(fees);
			s.setPhone(phone);
			s.setEmail(email);
			tx=ss.beginTransaction();
			ss.save(s);
			tx.commit();
			ss.close();
			res.sendRedirect("success.html");
		}
		catch(Exception ae)
		{	
			tx.rollback();	
			}	
	
	}}




