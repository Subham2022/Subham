package com.subham.mal.test;

import com.subham.mal.dao.DaoException;
import com.subham.mal.dao.PersonDao;
import com.subham.mal.dao.impl.JdbcPersonDao;
import com.subham.mal.entity.Person;

public class GetOnePerson {

	public static void main(String[] args) throws DaoException {
		PersonDao dao=new JdbcPersonDao();
		int id=102;
		Person p=dao.getPerson(id);
		if(p==null)
		{
			System.out.println("Data not found");
		}
		else
		{
			System.out.println(p);
		}
		

	}

}
