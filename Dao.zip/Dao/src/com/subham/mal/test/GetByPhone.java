package com.subham.mal.test;

import com.subham.mal.dao.DaoException;
import com.subham.mal.dao.PersonDao;
import com.subham.mal.dao.impl.JdbcPersonDao;
import com.subham.mal.entity.Person;

public class GetByPhone {

	public static void main(String[] args) throws DaoException {
		String phone="844556677";
		PersonDao dao=new JdbcPersonDao();
		Person p=dao.getPersonByPhone(phone);
		if(p==null)
		{
			System.out.println("Data not found");
		}
		else
		{
			System.out.println(p);
		}
	}

}
