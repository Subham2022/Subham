package com.subham.mal.test;

import com.subham.mal.dao.DaoException;
import com.subham.mal.dao.PersonDao;
import com.subham.mal.dao.impl.JdbcPersonDao;
import com.subham.mal.entity.Person;

public class UpdatePerson {

	public static void main(String[] args) throws DaoException {
		
		int id=102;
		
	
		PersonDao dao=new JdbcPersonDao();
		Person p=dao.getPerson(id);
		if(p==null)
		{
			System.out.println("Data is not available");
		}
		else
		{
			Person p1=new Person(101,"Subham","Mal","844556677","Subham@sm.com");
			dao.updatePerson(p1);
			System.out.println("Updated");
		}
		
		
		
		

	}

}
