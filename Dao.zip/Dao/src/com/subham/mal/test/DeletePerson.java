package com.subham.mal.test;

import com.subham.mal.dao.DaoException;
import com.subham.mal.dao.PersonDao;
import com.subham.mal.dao.impl.JdbcPersonDao;
import com.subham.mal.entity.Person;

public class DeletePerson {

	public static void main(String[] args) throws DaoException {
		PersonDao dao=new JdbcPersonDao();
		int id=101;
		
		dao.deletePerson(id);
		System.out.println("Person data deleted");

	}

}
