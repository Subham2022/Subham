package com.subham.mal.util;

import java.sql.Connection;
import java.sql.DriverManager;

import com.subham.mal.dao.DaoException;

public class DbUtil {
	
	public static Connection getConnection() throws DaoException, Exception
	{
		String driver,url,user,password;
		driver="oracle.jdbc.driver.OracleDriver";
		url="jdbc:oracle:thin:@localhost:1521:xe";
		user="System";
		password="Mko0!qaZ";
		Class.forName(driver);
		return DriverManager.getConnection(url,user,password);
	}

}
